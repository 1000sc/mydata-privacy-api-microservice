package egovframework.let.dashboard.service;


import java.util.UUID;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

import egovframework.let.dashboard.config.KafkaConfig;
import egovframework.let.dashboard.vo.VisualMasterVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class ProducerService {
	private final KafkaTemplate<String, Object> kafkaTemplate;

	public void produceInfo(final VisualMasterVO masterVo) {
		String key = UUID.randomUUID().toString();
		

		ListenableFuture<SendResult<String, Object>> future = kafkaTemplate.send(KafkaConfig.TOPIC_INFO, masterVo);
		

		
	}
}