package egovframework.let.dashboard.service;
import java.net.URI;
import java.util.List;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import egovframework.com.cmm.service.ResultVO;
import egovframework.let.dashboard.dao.PrivacyDAO;
import egovframework.let.dashboard.vo.ThirdServeResultVO;
import egovframework.let.dashboard.vo.ThirdServeVO;
import egovframework.let.dashboard.vo.UserInfoVO;
import egovframework.let.dashboard.vo.VisualMasterVO;
import egovframework.let.dashboard.vo.VisualSearchParam;
import egovframework.let.dashboard.vo.VisualVO;


/**
 * 게시판 속성관리를 위한 서비스 구현 클래스
 * @author 공통 서비스 개발팀 한성곤
 * @since 2009.08.25
 * @version 1.0
 * @see
 *  
 * <pre>
 * << 개정이력(Modification Information) >>
 * 
 *   수정일      수정자          수정내용
 *  -------    --------    ---------------------------
 *  2009.08.25  한성곤          최초 생성
 *  2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성 
 *  
 *  </pre>
 */
@Service("VisualService")
public class PrivacyApiServiceImpl extends EgovAbstractServiceImpl implements PrivacyApiService {

    @Resource(name = "PrivacyDAO")
    private PrivacyDAO privacyDAO;
    
    @Autowired
    private ProducerService producerService;
        
    @Autowired
    private RestTemplate restTemplate;
    
    @Value("${api.analyze.url}")
    private String analyzeServiceUrl;
    
    @Value("${api.thirdserve.url}")
    private String thirdServeUrl;
    
    @Value("${api.retractReq.url}")
    private String retractReq;
    
    

   
    /**
     * 서비스 현황 조회
     * REST에서 DB 조회로 대체
     */
	@Override
	public List<VisualVO> selectInfoList(VisualSearchParam searchParam) throws Exception {
		List<VisualVO> resultList = (List<VisualVO>) privacyDAO.selectInfoList("kr.or.mydataplatform.svc.com.selectInfoList", searchParam);
		VisualMasterVO masterVo = new VisualMasterVO();
		masterVo.setId(searchParam.getId());
		masterVo.setVoList(resultList);
		// -- kafka에 저장
		//producerService.produceInfo(masterVo);
		return resultList;
	}


	/**
     * 사용자 정보 조회
     */
	@Override
	public UserInfoVO selectUserInfo(String id) throws Exception {
		return privacyDAO.selectUserInfo("kr.or.mydataplatform.svc.com.selectUserInfo", id);
	}
	
	


	/**
	 * 서비스 분석 
	 * Analyze Service 호출
	 */
	@Override
	public List<VisualVO> analyzeInfo(String id) throws Exception {
		URI uri = UriComponentsBuilder
                .fromUriString(analyzeServiceUrl)
                .path("/api/v1/privacy/annalyzeinfo/{id}")   // 중계전문코드 / 전송요구서 id
                .encode()
                .build()
                .expand(id) 
                .toUri();
		ResponseEntity<ResultVO> responseEntity = restTemplate.getForEntity(uri, ResultVO.class);
		return null;
	}
	
	/**
	 * 제3자 정보 제공 조회
	 */
	@Override
	public List<ThirdServeVO> thirdServeInfo(VisualSearchParam searchParam) throws Exception {
		URI uri = UriComponentsBuilder
                .fromUriString(thirdServeUrl)
                .path("/api/v1/selectListAgreement/{rsognCd}/{trsmRqustfId}")   // 중계전문코드 / 전송요구서 id
                .encode()
                .build()
                .expand(searchParam.getRsognCd(),searchParam.getTrsmRqustfId()) //"TRAAAAB10001,tedst123" 복수의 값을 넣어야 할 경우 ,를 추가하여 구분
                .toUri();
		
		ResponseEntity<ThirdServeResultVO> responseEntity = restTemplate.getForEntity(uri, ThirdServeResultVO.class);
		List<ThirdServeVO>  rsList = responseEntity.getBody().getResults();
		return rsList;
	}
	
	
	/**
	 * 철회요청
	 */
	@Override
	public void retractReq(VisualSearchParam searchParam) throws Exception {
	/*
		URI uri = UriComponentsBuilder
	            .fromUriString(thirdServeUrl)
	            .path("/api/v1/selectRequestHistory")
	            .encode()
	            .build()
	            .expand()
	            .toUri();
		
		ResponseEntity<Object> responseEntity = restTemplate.postForEntity(uri, searchParam, Object.class);
		responseEntity.getBody();
	*/
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");

        //String requestBody = "{   \"certCi\":\"272547\",   \"mbrMngId\":\"PT202409090000000216\",   \"inqBgngYmd\":\"20230131\",   \"inqEndYmd\":\"20230404\",   \"curPage\": 1,   \"rowSizePerPage\":10,   \"srchTrsmRqustSttsCd\": \"11111\",   \"srchPtcpInstSeCd\": \"\",  \"srchPtcpInstNm\": \"\",  \"srchTdptyPvsnAgreYn\": \"ALL\",  \"api\": \"N\"}";
        HttpEntity<VisualSearchParam> request = new HttpEntity<>(searchParam, headers);
        restTemplate.postForObject(retractReq+"/api/v1/selectRequestHistory", request, Object.class);
		
	}
    
}
