package egovframework.let.dashboard.service;

import java.util.List;

import egovframework.let.dashboard.vo.ThirdServeVO;
import egovframework.let.dashboard.vo.UserInfoVO;
import egovframework.let.dashboard.vo.VisualSearchParam;
import egovframework.let.dashboard.vo.VisualVO;

/**
 * 게시판 속성관리를 위한 서비스 인터페이스 클래스
 * @author 공통 서비스 개발팀 한성곤
 * @since 2009.08.25
 * @version 1.0
 * @see
 *  
 * <pre>
 * << 개정이력(Modification Information) >>
 * 
 *   수정일      수정자          수정내용
 *  -------    --------    ---------------------------
 *  2009.08.25  한성곤          최초 생성
 *  2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성 
 *  
 *  </pre>
 */
public interface PrivacyApiService {

	/**
	 * 리스트 조회
	 * 
	 * @param searchVO
	 * @exception Exception Exception
	 */
	public List<VisualVO>  selectInfoList(VisualSearchParam searchVO) throws Exception;
	
	
	/**
	 * 사용자 정보 조회
	 * 
	 * @param searchVO
	 * @exception Exception Exception
	 */
	public UserInfoVO selectUserInfo(String id) throws Exception;
	
	
	
	/**
	 * 서비스 분석 (팝업)
	 * 
	 * @param id
	 * @exception Exception Exception
	 */
	public List<VisualVO>  analyzeInfo(String id) throws Exception;
	
	
	public List<ThirdServeVO>  thirdServeInfo(VisualSearchParam searchParam) throws Exception;
	
	public void retractReq(VisualSearchParam searchParam) throws Exception ;
	
	
	

}