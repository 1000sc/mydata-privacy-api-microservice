package egovframework.let.dashboard.config;

import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.util.MultiValueMap;

import lombok.Getter;
import lombok.NonNull;

@Getter
public class RestHttpClient {
    private HttpMethod method;
    private String url;
    private MultiValueMap<String, String> multiValueParams;
    private Map<String, Object> hashMapParams;
    private HttpHeader headers;

    public RestHttpClient(@NonNull HttpMethod method, @NonNull String url){
        this.method = method;
        this.url = url;
    }


    public RestHttpClient(@NonNull HttpMethod method, @NonNull String url, HttpHeader headers){
        this.method = method;
        this.url = url;
        this.headers = headers;
    }
    
    public RestHttpClient(@NonNull HttpMethod method, @NonNull String url, MultiValueMap<String, String> params){
        this.method = method;
        this.url = url;
        this.multiValueParams = params;
    }

    public RestHttpClient(@NonNull HttpMethod method, @NonNull String url, MultiValueMap<String, String> params, HttpHeader headers){
        this.method = method;
        this.url = url;
        this.multiValueParams = params;
        this.headers = headers;
    }

    public RestHttpClient(@NonNull HttpMethod method, @NonNull String url, Map<String, Object> params){
        this.method = method;
        this.url = url;
        this.hashMapParams = params;
    }

    public RestHttpClient(@NonNull HttpMethod method, @NonNull String url, Map<String, Object> params, HttpHeader headers){
        this.method = method;
        this.url = url;
        this.hashMapParams = params;
        this.headers = headers;
    }

    public void addHeader(String key, String value){
        this.getHeaders().addHeader(key, value);
    }

    public void addHeader(Map<String, String> newKeyValue){
        this.getHeaders().addHeader(newKeyValue);
    }
//
//    public void addParam(String key, String value){
//        if(this.params == null)
//            this.params = new LinkedMultiValueMap<String, String>();
//        this.params.add(key, value);
//    }

    public HttpEntity<MultiValueMap<String, String>> toMultiValueEntity(){
        return new HttpEntity<MultiValueMap<String, String>>(this.multiValueParams, this.headers.build());
    }
    public HttpEntity<Map<String, Object>> toHashMapEntity(){
        return new HttpEntity<Map<String, Object>>(this.hashMapParams, this.headers.build());
    }
    

    public HttpEntity toEntity(){
    	if (hashMapParams!=null)
    		return this.toHashMapEntity();
    	else 
    		return this.toMultiValueEntity();
    		
    }
}

