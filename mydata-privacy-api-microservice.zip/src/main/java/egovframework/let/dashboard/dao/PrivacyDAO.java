package egovframework.let.dashboard.dao;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.let.dashboard.vo.UserInfoVO;
import egovframework.let.dashboard.vo.VisualSearchParam;
import egovframework.let.dashboard.vo.VisualVO;

@Repository("PrivacyDAO")
public class PrivacyDAO extends EgovAbstractMapper {
	
	@SuppressWarnings("unchecked")
	public List<VisualVO> selectInfoList(String queryId, VisualSearchParam vo) throws Exception {
		return super.selectList(queryId, vo);
	}
	
	@SuppressWarnings("unchecked")
	public UserInfoVO selectUserInfo(String queryId, String id) throws Exception {
		return super.selectOne(queryId, id);
	}
}
