package egovframework.let.dashboard.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import egovframework.com.cmm.ResponseCode;
import egovframework.com.cmm.service.ResultVO;
import egovframework.com.cmm.util.DateUtil;
import egovframework.let.dashboard.service.PrivacyApiService;
import egovframework.let.dashboard.vo.PrivacyResultVO;
import egovframework.let.dashboard.vo.ThirdServeResultVO;
import egovframework.let.dashboard.vo.ThirdServeVO;
import egovframework.let.dashboard.vo.VisualSearchParam;
import egovframework.let.dashboard.vo.VisualVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * 일반 로그인을 처리하는 컨트롤러 클래스
 * @author 공통서비스 개발팀 박지욱
 * @since 2009.03.06
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *  수정일      수정자      수정내용
 *  -------            --------        ---------------------------
 *  2009.03.06  박지욱     최초 생성
 *  2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 *  </pre>
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/privacy")
@Tag(name="ServiceApiController",description = "서비스 관련")
public class PrivacyApiController {
	
	@Autowired
	private PrivacyApiService privacyApiService;

	/**
	 * 제3자 현황 조회
	 * @param vo - 아이디, 비밀번호가 담긴 LoginVO
	 * @param request - 세션처리를 위한 HttpServletRequest
	 * @return result - 로그인결과(세션정보)
	 * @exception Exception
	 */

	@Operation(
			summary = "제3자 제공 현황",
			description = "제3자 제공 현황",
			tags = {""}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "로그인 성공"),
			@ApiResponse(responseCode = "300", description = "로그인 실패")
	})
	@GetMapping(value = "/third-serve")
	public ThirdServeResultVO thirdServe(VisualSearchParam searchParam) throws Exception {
		ThirdServeResultVO resultVO = new ThirdServeResultVO();
		
		if(searchParam.getDummyYn() != null && searchParam.getDummyYn().equals("Y")){
			resultVO.setResults(getDummyThirdServe());
		}else {
			List<ThirdServeVO>  list = privacyApiService.thirdServeInfo(searchParam);
			
			resultVO.setResults(list);
		}
		
		resultVO.setTimestamp(DateUtil.getCurrentTimeStamp().toString());
		resultVO.setStatus("200");
		resultVO.setMessageType("info");
		resultVO.setMessage("info");
		return resultVO;
		
	}
	
	@Operation(
			summary = " 전송요구 내역조회전송지원-103" ,
			description = "REST API 호출대신에 DB에서 조회 > 로그인 시 조회됨",
			tags = {""}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "조회 성공"),
			@ApiResponse(responseCode = "403", description = "인가된 사용자가 아님")
	})
	@GetMapping(value = "/requestinfo/{mbrMngId}")
	public ResultVO selectPrivacyList(@PathVariable("mbrMngId") String mbrMngId, VisualSearchParam searchParam) throws Exception {
		ResultVO resultVO = new ResultVO();
		PrivacyResultVO privacyResultVO = new PrivacyResultVO();
		if(searchParam.getDummyYn() != null && searchParam.getDummyYn().equals("Y")){
			privacyResultVO.setTransferRequestDtos(getDummyRequestinfo());
		
		}else {
			searchParam.setSrchTrsmRqustSttsCd("A");
			searchParam.setMbrMngId(mbrMngId);
			List<VisualVO> list = privacyApiService.selectInfoList(searchParam);
			privacyResultVO.setTransferRequestDtos(list);
		}
		
		resultVO.setResults(privacyResultVO);
		resultVO.setTimestamp(DateUtil.getCurrentTimeStamp().toString());
		resultVO.setStatus(ResponseCode.SUCCESS.getCode());
		resultVO.setResultCode(ResponseCode.SUCCESS.getCode());
		resultVO.setResultMessage(ResponseCode.SUCCESS.getMessage());
		
		return resultVO;
	}
	
	@Operation(
			summary = " 전송요구 내역조회전송지원-103" ,
			description = "REST API 호출대신에 DB에서 조회 > 로그인 시 조회됨",
			tags = {""}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "조회 성공"),
			@ApiResponse(responseCode = "403", description = "인가된 사용자가 아님")
	})
	@GetMapping(value = "/revokedinfo/{mbrMngId}")
	public ResultVO selectRevokedPrivacyList(@PathVariable("mbrMngId") String mbrMngId, VisualSearchParam searchParam) throws Exception {
		ResultVO resultVO = new ResultVO();
		PrivacyResultVO privacyResultVO = new PrivacyResultVO();
		if(searchParam.getDummyYn() != null && searchParam.getDummyYn().equals("Y")){
			privacyResultVO.setTransferRequestDtos(getDummyRequestinfo());
		
		}else {
		
			searchParam.setMbrMngId(mbrMngId);
			searchParam.setSrchTrsmRqustSttsCd("R");
			List<VisualVO> list = privacyApiService.selectInfoList(searchParam);
			privacyResultVO.setTransferRequestDtos(list);
		}
		
		resultVO.setResults(privacyResultVO);
		resultVO.setTimestamp(DateUtil.getCurrentTimeStamp().toString());
		resultVO.setStatus(ResponseCode.SUCCESS.getCode());
		resultVO.setResultCode(ResponseCode.SUCCESS.getCode());
		resultVO.setResultMessage(ResponseCode.SUCCESS.getMessage());
		
		return resultVO;
	}
	
	@Operation(
			summary = " 서비스 상세 보기 : 서비스 분석 (팝업)" ,
			description = "Analyze Service REST API 호출",
			tags = {""}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "조회 성공"),
			@ApiResponse(responseCode = "403", description = "인가된 사용자가 아님")
	})
	@GetMapping(value = "/analyzeservice/{id}")
	public ResultVO analyzeService(@PathVariable("id") String id) throws Exception {
		ResultVO resultVO = new ResultVO();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		List<VisualVO> list = privacyApiService.analyzeInfo(id);
		resultMap.put("result", list);
		
		resultVO.setResults(resultMap);
		resultVO.setResultCode(ResponseCode.SUCCESS.getCode());
		resultVO.setResultMessage(ResponseCode.SUCCESS.getMessage());
		
		return resultVO;
	}
	
	@Operation(
			summary = "철회 요청" ,
			description = "철회 요청 -> REST 호출 필요",
			tags = {""}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "조회 성공"),
			@ApiResponse(responseCode = "403", description = "인가된 사용자가 아님")
	})
	@PostMapping(value = "/retract")
	public ResultVO retractReq(@RequestBody VisualSearchParam searchParam) throws Exception {
		ResultVO resultVO = new ResultVO();
		
		if(searchParam.getDummyYn() != null && searchParam.getDummyYn().equals("Y")){
			
		
		}else {
			privacyApiService.retractReq(searchParam);
		}
		
		resultVO.setResults(null);
		resultVO.setMessageType("info");
		resultVO.setMessage("info");
		resultVO.setStatus(200);
		resultVO.setResultCode(ResponseCode.SUCCESS.getCode());
		resultVO.setResultMessage(ResponseCode.SUCCESS.getMessage());
		
		return resultVO;
	}
	
	private List<VisualVO> getDummyRequestinfo(){
		List<VisualVO> list = new ArrayList<VisualVO>();
		VisualVO vo = new VisualVO();
		/*vo.setTrsmRqustfId("359157");
		vo.setCertCi("CI");
		vo.setSrvcCd("SC00000002");
		vo.setFldCd("C1");
		vo.setRsognCd("TR0000000002");
		vo.setInfoTrsmInstCd("PV0000000002");
		vo.setTrsmRqustSttsCd("2");
		vo.setTdptyPvsnAgreYn("Y");
		vo.setTrsmRqustYmd("20240101");
		vo.setTrsmRqustRcnttYmd("20240102");
		vo.setTrsmRqustPrps("전송요구목적1");
		vo.setTrsmCylNm("1/w");
		vo.setPrvcHldExpryYmd("20240103");
		vo.setAuthrtScpeNm("api1 api2 api3");
		vo.setRgtrId("AL202401010000000001");
		vo.setMdfrId("AL202401010000000001");
		vo.setSrchDt("2024-09-03 14:03:33");
		vo.setInqBgngYmd("20230904");
		vo.setInqEndYmd("20240903");
		vo.setMbrMngId("PT202408120000000004");
		vo.setPtcpInstNm("수신자001");
		vo.setSrvcNm("서비스002");
		vo.setInfoTrsmInstNm("전송자002");
		vo.setTrsmRqustSttsNm("종료");
		vo.setNum("1");
		*/
		list.add(vo);
		return list;
	}
	
	private List<ThirdServeVO> getDummyThirdServe(){
		List<ThirdServeVO> list = new ArrayList<ThirdServeVO>();
		ThirdServeVO vo = new ThirdServeVO();
		vo.setProConsentNo("CONSENT_NO_1");
		vo.setOnceYn("Y");
		vo.setProvConsentNm("마케팅 활용을 위한 제3자 제공 동의서");
		vo.setProvConsentDtime("20240502182330");
		vo.setSndInstCd("TESTSRVC02");
		vo.setConsentRcvNm("LGCNS,삼성카드,국민은행,비바리퍼블리카");
		vo.setProvConsentPurpose("마케팅 어쩌구저쩌구목적");
		vo.setProvConsentPeriod("정보주체의 탈퇴 혹은 동의 해제까지");
		vo.setProvConsentAsset("회원정보, 통신사 데이터 이용내역, 휴대전화번호");
		list.add(vo);
		vo = new ThirdServeVO();
		vo.setProConsentNo("CONSENT_NO_2");
		vo.setOnceYn("Y");
		vo.setProvConsentNm("보험상품 추천을 위한 제3자 제공 동의서");
		vo.setProvConsentDtime("20240223154220");
		vo.setSndInstCd("TESTSRVC02");
		vo.setConsentRcvNm("한화생명,삼성생명,미래에셋생명");
		vo.setProvConsentPurpose("보험상품 추천을 위한 데이터 제3자 제공, 회원 보험상품 분석");
		vo.setProvConsentPeriod("정보주체의 탈퇴 혹은 동의 해제까지");
		vo.setProvConsentAsset("휴대전화번호, 통신사 납부 내역, 기타 등등 보험상품 추천에 도움 ");
		list.add(vo);
		
		return list;
	}
}