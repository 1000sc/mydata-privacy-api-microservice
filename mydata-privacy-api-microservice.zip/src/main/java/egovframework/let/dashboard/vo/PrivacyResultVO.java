package egovframework.let.dashboard.vo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * 사용자 정보 조회를 위한 VO  클래스
 * @author 
 * @since 
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2024.10.19  천석찬          최초 생성
 *
 * </pre>
 */
@Getter
@Setter
public class PrivacyResultVO implements Serializable {
	
	@Schema(description = "transferRequestDtos")
	private List<VisualVO> transferRequestDtos ;
	
	/**  **/
	private int totalCnt;
	
	/**  **/
	private int curPage;
	
	/**  **/
	private int rowSizePerPage;
	
	/**  **/
	private int pageSize;
	
	/**  **/
	private int firstRow;
	
	/**  **/
	private int lastRow;
	
	/**  **/
	private int totalPageCount;
	
	/**  **/
	private int firstPage;
	
	/**  **/
	private int lastPage;

	
    /**
     * toString 메소드를 대치한다.
     */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}