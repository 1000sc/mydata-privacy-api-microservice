package egovframework.let.dashboard.vo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * 사용자 정보 조회를 위한 VO  클래스
 * @author 
 * @since 
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2024.10.19  천석찬          최초 생성
 *
 * </pre>
 */
@Getter
@Setter
public class ThirdServeVO implements Serializable {
	
	/**  proConsentNo **/
	private String proConsentNo;
	
	/** 일회성 제공 여부  **/
	private String onceYn;
	
	/** 동의서명  **/
	private String provConsentNm;
	
	/**  동의일시 **/
	private String provConsentDtime;
	
	/**  제공하는자 **/
	private String sndInstCd;
	
	/**  제공받는자 **/
	private String consentRcvNm;
	
	/**  제공받는자의이용목적 **/
	private String provConsentPurpose;
	
	/** 보유 및 이용기간 **/
	private String provConsentPeriod;
	
	/**  제공항목 **/
	private String provConsentAsset;
	
	
	

	
    /**
     * toString 메소드를 대치한다.
     */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}