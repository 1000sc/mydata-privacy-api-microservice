package egovframework.let.dashboard.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * 사용자 정보 조회를 위한 VO  클래스
 * @author 
 * @since 
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2024.10.19  천석찬          최초 생성
 *
 * </pre>
 */
@Getter
@Setter
public class VisualVO implements Serializable {
	/** seq no **/
	@JsonProperty("id")
	private String id;
	
	/** 중계전문기관 코드 **/
	@JsonProperty("rsognCd")
	private String rsognCd;
	
	/** 서비스코드 **/
	@JsonProperty("service_code")
	private String srvcCd;
	
	/** 서비스명 **/
	@JsonProperty("title")
	private String srvcNm;
	
	/** 정보수신자코드**/
	@JsonProperty("ptcpInstCd")
	private String ptcpInstCd;
	
	/** 정보수신자명 **/
	@JsonProperty("serviceProvider")
	private String ptcpInstNm; 
	
	/** 전송요구상태코드 :  철외여부 0: 전송중 1: 철회 2: 종료 **/
	@JsonProperty("serviceProvider")
	private String trsmRqustSttsCd; 
	
	/** 분야코드 */
	@JsonProperty("fld_cd")
	private String fldCd; 
	
	
	
	private String MBR_MNG_ID; 
	
	
	/** 정보제공자 cd **/
	//@JsonProperty("data_provider_code")
	//private String infoTrsmInstCd; 
	  
	/** 정보제공자 nm **/
	//@JsonProperty("data_provider")
	//private String infoTrsmInstNm; 
	
	
	/** 제3자제공동의여부 **/
	//@JsonProperty("third_party_sharing_allowed")
	//private String tdptyPvsnAgreYn; 
	
	/** 개인정보보유만료일자 **/
	//@JsonProperty("expires_at")
	//private String prvcHldExpryYmd;
	
	/** 전송요구철회일자 **/
	//@JsonProperty("revoked_at")
	//private String trsmRqustRcnttYmd;
	
	/** 전송요구일자 **/
	//@JsonProperty("started_at")
	//private String trsmRqustYmd;
	
	/** 권한범위명 **/
	//private String authrtScpeNm;
	
	/** 전송요구서아이디 **/
	//private String trsmRqustfId;
	
	/** CI **/
	//private String certCi;
	
	/** 분야코드 **/
	//private String fldCd;
	
	/** 전송요구상태코드 **/
	//private String trsmRqustSttsCd;
	
	/** 전송요구종료일자 **/
	//private String trsmRqustEndYmd;
	
	/** 전송요구목적 **/
	//private String trsmRqustPrps;
	
	/** 전송주기명 **/
	//private String trsmCylNm;
	
	/** 등록자아이디 **/
	private String rgtrId;
	
	/**  등록자아이디 **/
	private String mdfrId;
	
	/**  검색일시**/
	private String srchDt;
	
	/** 조회시작일자 **/
	private String inqBgngYmd;
	
	/**  조회종료일자 **/
	private String inqEndYmd;
	
	/** 회원관리아이디 **/
	private String mbrMngId;
	
	/** 상태명 **/
	//private String trsmRqustSttsNm;
	
	/** 번호 **/
	//private String num;
	
		
	@JsonProperty("share_requests")
	private List<VisualServeInfoVO> shareRequests;

    /**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = -6156707290504312279L;

	

    /**
     * toString 메소드를 대치한다.
     */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}