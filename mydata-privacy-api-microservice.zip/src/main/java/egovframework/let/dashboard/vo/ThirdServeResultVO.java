package egovframework.let.dashboard.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import lombok.Getter;
import lombok.Setter;

/**
 * 사용자 정보 조회를 위한 VO  클래스
 * @author 
 * @since 
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2024.10.19  천석찬          최초 생성
 *
 * </pre>
 */
@Getter
@Setter
public class ThirdServeResultVO implements Serializable {
	
	/**  timestamp **/
	private String timestamp;
	
	/** status  **/
	private String status;
	
	/** messageType  **/
	private String messageType;
	
	/**  message **/
	private String message;
	
	/**   **/
	private List<ThirdServeVO> results;
	

	
    /**
     * toString 메소드를 대치한다.
     */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}