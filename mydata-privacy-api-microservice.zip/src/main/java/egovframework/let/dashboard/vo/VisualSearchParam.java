package egovframework.let.dashboard.vo;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * 사용자 정보 조회를 위한 VO  클래스
 * @author 
 * @since 
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2024.10.19  천석찬          최초 생성
 *
 * </pre>
 */
@Getter
@Setter
public class VisualSearchParam implements Serializable {

    /**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = -6156707290504312279L;
	
	/** CI  */
	private String certCi;
	
	/** 사용자ID(포털로그인)  */
	private String mbrMngId;
	
	/** 더미 데이터 리턴 유뮤  */
	private String dummyYn;
	
	/** "TR0000000002",//중계전문기관코드 **/
	private String rsognCd;
	
	/** 전송요구서 ID  **/
	private String trsmRqustfId;
	
	/** 정보전송기관코드  */
	private String infoTrsmInstCd;
	
	/** 정보수신서비스코드  */
	private String infoRcptnSrvcCd;
	
	private String inqBgngYmd;

	private String inqEndYmd;
	
	private int curPage;
	
	private int rowSizePerPage;
	
	private String srchTrsmRqustSttsCd;
	
	private String srchPtcpInstSeCd;
	
	private String srchPtcpInstNm;
	
	private String srchTdptyPvsnAgreYn;
	
	private String api;
	

	/** 유일 아이디 */
    private String id = "";

    /** 사용자 아이디 */
    private String userId = "";

    /** 사용자 명 */
    private String userName = "";

    /** 검색시작일 */
    private String searchBgnDe = "";

    /** 검색조건 */
    private String searchCnd = "";

    /** 검색종료일 */
    private String searchEndDe = "";

    /** 검색단어 */
    private String searchWrd = "";

    /** 정렬순서(DESC,ASC) */
    private String sortOrdr = "";

    /** 검색사용여부 */
    private String searchUseYn = "";

    /** 현재페이지 */
    private int pageIndex = 1;

    /** 페이지갯수 */
    private int pageUnit = 10;

    /** 페이지사이즈 */
    private int pageSize = 10;

    

    /** 페이지당 레코드 개수 */
    private int recordCountPerPage = 10;


    /**
     * toString 메소드를 대치한다.
     */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}