package egovframework.let.dashboard.vo;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * 사용자 정보 조회를 위한 VO  클래스
 * @author 
 * @since 
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2024.10.19  천석찬          최초 생성
 *
 * </pre>
 */
@Getter
@Setter
public class VisualServeInfoVO implements Serializable {
	/** seq no **/
	@JsonProperty("id")
	private String id;
	
    @JsonProperty("data_provider_code")
	private String infoTrsmInstCd; 
	  
	/** 정보제공자 nm **/
	@JsonProperty("data_provider")
	private String infoTrsmInstNm; 
	
	
	/** 제3자제공동의여부 **/
	@JsonProperty("third_party_sharing_allowed")
	private String tdptyPvsnAgreYn; 
	
	/** 개인정보보유만료일자 **/
	@JsonProperty("expires_at")
	private String prvcHldExpryYmd;
	
	/** 전송요구철회일자 **/
	@JsonProperty("revoked_at")
	private String trsmRqustRcnttYmd;
	
	/** 전송요구일자 **/
	@JsonProperty("started_at")
	private String trsmRqustYmd;
	
	/** 권한범위명 **/
	@JsonProperty("data_provided")
	private String authrtScpeNm;
	
	/** 철외여부 0: 전송중 1: 철회 2: 종료 **/
	@JsonProperty("trsm_rqust_stts_cd")
	private String trsmRqustSttsCd;

    /**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = -6156707290504312279L;

	

    /**
     * toString 메소드를 대치한다.
     */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}